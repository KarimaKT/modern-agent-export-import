"""
retail_report.py — Retail Sales YoY Report Calculator
Part of the retail-sales-report Agent Skill.

Given a list of category revenue records (current year + prior year),
computes YoY absolute change and YoY % change, then returns a
formatted markdown table sorted by current year revenue descending.

Usage (called by the Copilot Studio agent via Code Interpreter):
    raw_data = [
        {"category": "Beauty",          "revenue_current": 44489.69, "revenue_prior": 18234.12},
        {"category": "Electronics",     "revenue_current": 36562.26, "revenue_prior": 41203.55},
        {"category": "Home & Garden",   "revenue_current": 46327.41, "revenue_prior": 39102.88},
        {"category": "Apparel",         "revenue_current": 40734.11, "revenue_prior": 37891.20},
        {"category": "Sports & Outdoors","revenue_current": 40819.02, "revenue_prior": 36211.45},
    ]
    print(format_yoy_table(raw_data))
"""

def format_yoy_table(raw_data: list[dict]) -> str:
    """
    Compute YoY metrics and return a formatted markdown table.
    
    Args:
        raw_data: list of dicts with keys:
                  - category (str)
                  - revenue_current (float)
                  - revenue_prior (float)
    
    Returns:
        Markdown table string with YoY columns, sorted by current revenue desc.
    """
    rows = []
    for item in raw_data:
        cat     = item["category"]
        curr    = float(item["revenue_current"])
        prior   = float(item["revenue_prior"])
        yoy_abs = curr - prior
        yoy_pct = ((curr - prior) / prior * 100) if prior != 0 else float("inf")
        rows.append({
            "category":        cat,
            "revenue_current": curr,
            "revenue_prior":   prior,
            "yoy_abs":         yoy_abs,
            "yoy_pct":         yoy_pct,
        })
    
    # Sort by current year revenue descending
    rows.sort(key=lambda r: r["revenue_current"], reverse=True)
    
    # Format as markdown table
    lines = [
        "| Category | Current Year | Prior Year | YoY Change | YoY % |",
        "|---|---|---|---|---|",
    ]
    for r in rows:
        arrow  = "▲" if r["yoy_abs"] >= 0 else "▼"
        sign   = "+" if r["yoy_abs"] >= 0 else ""
        lines.append(
            f"| {r['category']} "
            f"| ${r['revenue_current']:,.2f} "
            f"| ${r['revenue_prior']:,.2f} "
            f"| {arrow} {sign}${r['yoy_abs']:,.2f} "
            f"| {sign}{r['yoy_pct']:.1f}% |"
        )
    
    return "\n".join(lines)


# Self-test — runs when script is executed directly
if __name__ == "__main__":
    sample = [
        {"category": "Beauty",           "revenue_current": 44489.69, "revenue_prior": 18234.12},
        {"category": "Electronics",      "revenue_current": 36562.26, "revenue_prior": 41203.55},
        {"category": "Home & Garden",    "revenue_current": 46327.41, "revenue_prior": 39102.88},
        {"category": "Apparel",          "revenue_current": 40734.11, "revenue_prior": 37891.20},
        {"category": "Sports & Outdoors","revenue_current": 40819.02, "revenue_prior": 36211.45},
    ]
    print(format_yoy_table(sample))
