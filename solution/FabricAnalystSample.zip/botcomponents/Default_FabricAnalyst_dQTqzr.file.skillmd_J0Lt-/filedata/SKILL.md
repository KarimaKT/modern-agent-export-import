---
name: retail-sales-report
description: Generate a formatted retail sales report with Year-over-Year calculations. Use this skill whenever the user asks for a sales report, retail numbers, revenue summary, or YoY analysis.
---

## Retail Sales Report Skill

When this skill is activated, you have access to a Python script `retail_report.py` that can calculate YoY metrics from raw data.

### When to use this skill
- User asks for a sales report, revenue summary, or retail numbers
- User asks to compare this year vs last year (YoY)
- User asks for category performance or trend analysis

### How to use the Python asset
Call the `retail_report.py` script with a data table from your DAX query results. It will:
1. Parse the raw DAX output (tab-separated rows)
2. Calculate Year-over-Year change (absolute and percentage)
3. Add a YoY column and sort by revenue descending
4. Return a formatted markdown table ready to paste into the chat

### Input format expected by the script
The script expects a variable `raw_data` as a list of dicts with keys:
- `category` (str)
- `revenue_current` (float) — current year revenue
- `revenue_prior` (float) — prior year revenue

### Output
A formatted markdown table with columns: Category | Current Year | Prior Year | YoY Change | YoY %

### Guidelines
- Always run the DAX query first to get raw numbers, then pass results to the script
- Present the formatted table to the user without modification
- After the table, add 2–3 sentences of narrative insight (top performer, biggest decline, overall trend)
- End with 3 follow-up questions the user might ask next
